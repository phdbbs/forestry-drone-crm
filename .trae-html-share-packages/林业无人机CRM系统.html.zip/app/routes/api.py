from flask import Blueprint, request, jsonify, abort, Response
from flask import current_app
from app import db
from app.models import (
    Customer, CustomerNews, Lead, Opportunity, OpportunityStage,
    StageRecord, Contact, Activity, KanbanBoard, KanbanColumn,
    KanbanCard, SystemConfig, Skill, FollowUp, ContactNews, CrawlLog
)
from app.services.matcher import match_lead
from app.services.serial import gen_serial
from app.services.skills import SkillRegistry
from sqlalchemy.orm import joinedload, selectinload
from datetime import datetime, timedelta
import requests as http_requests
import json
import csv
import io
from urllib.parse import quote

api = Blueprint('api', __name__)

def _require_fields(d, *fields):
    missing = [f for f in fields if not str(d.get(f) or '').strip()]
    if missing:
        abort(400, description=f"缺少必填字段: {', '.join(missing)}")


def _text(value, default=''):
    """可选文本字段归一化：None → 默认值，避免下游做切片时抛 NoneType 错误。"""
    if value is None:
        return default
    return value if isinstance(value, str) else str(value)


def _int_arg(name):
    """解析整数查询参数。非法值统一返回 400，避免静默忽略或抛出内部异常信息。"""
    raw = request.args.get(name)
    if raw is None or str(raw).strip() == '':
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        abort(400, description=f"{name} 必须为整数")

def _parse_date(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    for fmt in ('%Y-%m-%d', '%Y/%m/%d'):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    raise ValueError(f"日期格式不正确: {text}")

def _parse_datetime(value):
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    text = str(value).strip()
    for fmt in ('%Y-%m-%d', '%Y-%m-%d %H:%M', '%Y-%m-%dT%H:%M', '%Y-%m-%d %H:%M:%S'):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    raise ValueError(f"时间格式不正确: {text}")

def _first_board_column():
    board = KanbanBoard.query.order_by(KanbanBoard.id).first()
    if not board:
        # 无任何看板时自动创建默认看板，避免"添加到看板"静默失败
        board = KanbanBoard(name='业务跟进看板')
        db.session.add(board)
        db.session.flush()
        for i, name in enumerate(['待处理', '进行中', '已完成']):
            db.session.add(KanbanColumn(board_id=board.id, name=name, sort_order=i))
        db.session.flush()
    if board.columns:
        return board.columns[0]
    col = KanbanColumn(board_id=board.id, name='待处理', sort_order=0)
    db.session.add(col)
    db.session.flush()
    return col

def _add_kanban_card(title, description='', deadline=None, color='blue',
                     source_type='', source_id=None):
    col = _first_board_column()
    if not col:
        return None
    next_order = (db.session.query(db.func.max(KanbanCard.sort_order))
                  .filter_by(column_id=col.id).scalar() or 0) + 1
    card = KanbanCard(column_id=col.id, title=title, description=description,
                      deadline=deadline, label_color=color,
                      source_type=source_type, source_id=source_id,
                      sort_order=next_order)
    db.session.add(card)
    return card

@api.route('/skills', methods=['GET'])
def list_skills():
    skills = Skill.query.order_by(Skill.is_builtin.desc(), Skill.created_at).all()
    builtin = SkillRegistry.get_all()
    db_skills = [{"id": s.id, "name": s.name, "description": s.description, "icon": s.icon or "🔧", "is_builtin": s.is_builtin, "is_active": s.is_active, "config_json": s.config_json} for s in skills]
    return jsonify({"builtin": builtin, "custom": db_skills})

@api.route('/skills', methods=['POST'])
def create_skill():
    d = request.get_json()
    if Skill.query.filter_by(name=d['name']).first():
        return jsonify({"error": "技能名称已存在"}), 400
    s = Skill(name=d['name'], description=d.get('description',''), icon=d.get('icon','🔧'), is_builtin=False, is_active=True, config_json=d.get('config_json'))
    db.session.add(s)
    db.session.commit()
    return jsonify({"id": s.id, "name": s.name, "message": "创建成功"})

@api.route('/skills/<int:id>', methods=['PUT'])
def update_skill(id):
    s = Skill.query.get_or_404(id)
    if s.is_builtin:
        return jsonify({"error": "内置技能不可编辑"}), 400
    d = request.get_json()
    if 'name' in d: s.name = d['name']
    if 'description' in d: s.description = d['description']
    if 'icon' in d: s.icon = d['icon']
    if 'config_json' in d: s.config_json = d['config_json']
    db.session.commit()
    return jsonify({"id": s.id, "message": "更新成功"})

@api.route('/skills/<int:id>/toggle', methods=['POST'])
def toggle_skill(id):
    s = Skill.query.get_or_404(id)
    if s.is_builtin:
        return jsonify({"error": "内置技能不可禁用"}), 400
    s.is_active = not s.is_active
    db.session.commit()
    return jsonify({"id": s.id, "is_active": s.is_active, "message": "已" + ("启用" if s.is_active else "禁用")})

@api.route('/skills/<int:id>', methods=['DELETE'])
def delete_skill(id):
    s = Skill.query.get_or_404(id)
    if s.is_builtin:
        return jsonify({"error": "内置技能不可删除"}), 400
    db.session.delete(s)
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/skills/<name>/execute', methods=['POST'])
def execute_skill(name):
    data = request.get_json() or {}
    result = SkillRegistry.execute(name, **data)
    return jsonify(result)

@api.route('/dashboard', methods=['GET'])
def dashboard():
    leads = Lead.query.options(joinedload(Lead.customer)).filter_by(status='active').all()
    level_score = {'高匹配': 300, '中匹配': 200, '低匹配': 100}
    leads.sort(key=lambda l: -(level_score.get(l.match_level, 0)))
    now = datetime.now()
    today = now.strftime('%Y-%m-%d')
    today_activities = Activity.query.options(
        joinedload(Activity.contact), joinedload(Activity.customer)
    ).filter(db.func.date(Activity.activity_time) == today).all()
    today_followups = FollowUp.query.options(
        joinedload(FollowUp.contact)
    ).filter(db.func.date(FollowUp.plan_date) == today).all()
    # 用日期差计算剩余天数：当天截止（0 天）也算紧急；datetime 直接相减会把当天误判为 -1 天
    urgent_leads = [l for l in leads if l.deadline and 0 <= (l.deadline.date() - now.date()).days <= 3]
    opportunities = Opportunity.query.options(
        joinedload(Opportunity.customer)
    ).order_by(Opportunity.created_at.desc()).all()
    kanban_cards = KanbanCard.query.filter(KanbanCard.deadline.isnot(None)).order_by(KanbanCard.deadline).limit(10).all()
    return jsonify({
        "stats": {"active_leads": len(leads), "opportunities": len(opportunities), "today_activities": len(today_activities), "urgent_leads": len(urgent_leads), "today_followups": len(today_followups)},
        "urgent_leads": [{"id": l.id, "title": _text(l.title)[:60], "level": l.match_level, "deadline": str(l.deadline.date()) if l.deadline else None, "match_keywords": l.match_keywords, "customer_name": l.customer.name if l.customer else None} for l in urgent_leads[:5]],
        "opportunities": [{"id": o.id, "title": _text(o.title)[:60], "stage": o.current_stage, "amount": o.amount, "customer_name": o.customer.name if o.customer else None} for o in opportunities],
        "today_activities": [{"id": a.id, "method": a.method, "content": _text(a.content)[:80], "time": str(a.activity_time), "contact_name": a.contact.name if a.contact else None, "customer_name": a.customer.name if a.customer else None} for a in today_activities],
        "today_followups": [{"id": f.id, "content": _text(f.content)[:60], "contact_name": f.contact.name if f.contact else None, "plan_date": str(f.plan_date)} for f in today_followups],
        "kanban_cards": [{"id": c.id, "title": c.title, "deadline": str(c.deadline.date()) if c.deadline else None, "color": c.label_color} for c in kanban_cards],
    })

@api.route('/customers', methods=['GET'])
def list_customers():
    q = request.args.get('search', '')
    # 集合关联用 selectinload：joinedload 同时加载两个一对多集合会产生笛卡尔积
    customers = Customer.query.options(
        selectinload(Customer.contacts), selectinload(Customer.news_items)
    ).filter_by(is_archived=False)
    if q: customers = customers.filter(Customer.name.contains(q))
    return jsonify([{"id": c.id, "name": c.name, "short_name": c.short_name, "type": c.customer_type, "level": c.level, "region": c.region, "source": c.source, "contact_count": len(c.contacts), "news_count": len(c.news_items)} for c in customers.all()])

@api.route('/customers', methods=['POST'])
def create_customer():
    d = request.get_json() or {}
    _require_fields(d, 'name')
    c = Customer(name=str(d['name']).strip()[:200], short_name=d.get('short_name',''), customer_type=d.get('type',''), level=d.get('level',''), region=d.get('region',''), address=d.get('address',''), website=d.get('website',''), registration_capital=d.get('capital',''), operation_years=d.get('years',''), social_security_count=d.get('social_count'), business_scope=d.get('scope',''), intellectual_property=d.get('ip',''), department=d.get('dept',''), source=d.get('source',''), remark=d.get('remark',''))
    db.session.add(c)
    db.session.commit()
    return jsonify({"id": c.id, "message": "创建成功"})

@api.route('/customers/<int:id>', methods=['GET'])
def get_customer(id):
    c = Customer.query.get_or_404(id)
    return jsonify({"id": c.id, "name": c.name, "short_name": c.short_name, "type": c.customer_type, "level": c.level, "region": c.region, "address": c.address, "website": c.website, "capital": c.registration_capital, "years": c.operation_years, "social_count": c.social_security_count, "scope": c.business_scope, "ip": c.intellectual_property, "dept": c.department, "source": c.source, "remark": c.remark, "contacts": [{"id": ct.id, "name": ct.name, "title": ct.title, "phone": ct.phone, "importance": ct.importance} for ct in c.contacts], "opportunities": [{"id": o.id, "title": o.title, "amount": o.amount, "current_stage": o.current_stage, "probability": o.probability or 20, "expected_close": str(o.expected_close.date()) if o.expected_close else None} for o in c.opportunities], "news": [{"id": n.id, "title": n.title, "date": str(n.publish_date.date()) if n.publish_date else None, "type": n.change_type, "url": n.url, "source_name": n.source_name or '', "event_time": str(n.event_time.date()) if n.event_time else None, "content": (n.content or '')[:300]} for n in c.news_items]})

@api.route('/customers/<int:id>', methods=['PUT'])
def update_customer(id):
    c = Customer.query.get_or_404(id)
    d = request.get_json() or {}
    for key in ['name','short_name','customer_type','level','region','address','website','registration_capital','operation_years','business_scope','intellectual_property','department','source','remark']:
        if key in d: setattr(c, key, d[key])
    if 'social_count' in d: c.social_security_count = d['social_count']
    db.session.commit()
    return jsonify({"id": c.id, "message": "更新成功"})

@api.route('/customers/<int:id>', methods=['DELETE'])
def delete_customer(id):
    c = Customer.query.get_or_404(id)
    c.is_archived = True
    db.session.commit()
    return jsonify({"message": "已归档"})

@api.route('/leads', methods=['GET'])
def list_leads():
    q = request.args.get('search', '')
    status = request.args.get('status', '')
    level = request.args.get('level', '')
    region = request.args.get('region', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    query = Lead.query.options(joinedload(Lead.customer))
    if q: query = query.filter(Lead.title.contains(q) | Lead.serial_no.contains(q))
    if status: query = query.filter_by(status=status)
    if level: query = query.filter_by(match_level=level)
    if region: query = query.filter(Lead.region.contains(region))
    if date_from:
        d = _parse_date(date_from)
        if d: query = query.filter(Lead.created_at >= d)
    if date_to:
        d = _parse_date(date_to)
        if d: query = query.filter(Lead.created_at < d + timedelta(days=1))
    leads = query.order_by(Lead.created_at.desc()).all()
    result = []
    for l in leads:
        days_left = (l.deadline.date() - datetime.now().date()).days if l.deadline else None
        result.append({"id": l.id, "title": l.title, "bid_number": l.bid_number, "budget": l.budget, "deadline": str(l.deadline.date()) if l.deadline else None, "days_left": days_left, "region": l.region, "purchaser": l.purchaser, "contact_name": l.contact_name or '', "contact_phone": l.contact_phone or '', "address": l.address or '', "service_content": l.service_content, "match_keywords": l.match_keywords, "match_level": l.match_level, "match_score": l.match_score or 0, "match_reason": l.match_reason, "assignee": l.assignee or '', "bid_type": l.bid_type or '', "winner": l.winner or '', "related_customer_ids": l.related_customer_ids or '', "serial_no": l.serial_no or "", "reason": l.reason or "", "source_platform": l.source_platform, "source_url": l.source_url, "status": l.status, "customer_id": l.customer_id, "customer_name": l.customer.name if l.customer else None, "created_at": str(l.created_at.date()) if l.created_at else None})
    return jsonify(result)

@api.route('/leads', methods=['POST'])
def create_lead():
    d = request.get_json() or {}
    _require_fields(d, 'title')
    l = Lead(bid_number=d.get('bid_number',''), title=str(d['title']).strip()[:500], budget=d.get('budget',''), deadline=_parse_date(d.get('deadline')), region=d.get('region',''), purchaser=d.get('purchaser',''), contact_name=(d.get('contact_name') or '')[:100], contact_phone=(d.get('contact_phone') or '')[:100], address=(d.get('address') or '')[:300], service_content=d.get('service_content',''), source_url=d.get('source_url',''), source_platform=d.get('source_platform',''), customer_id=d.get('customer_id'))
    match_lead(l)
    l.serial_no = gen_serial(l.created_at or datetime.now())
    db.session.add(l)
    db.session.commit()
    return jsonify({"id": l.id, "message": "创建成功"})

@api.route('/leads/<int:id>', methods=['GET'])
def get_lead(id):
    l = Lead.query.get_or_404(id)
    return jsonify({"id": l.id, "title": l.title, "bid_number": l.bid_number, "budget": l.budget, "deadline": str(l.deadline.date()) if l.deadline else None, "region": l.region, "purchaser": l.purchaser, "contact_name": l.contact_name or '', "contact_phone": l.contact_phone or '', "address": l.address or '', "service_content": l.service_content, "match_keywords": l.match_keywords, "match_level": l.match_level, "match_score": l.match_score or 0, "match_reason": l.match_reason, "bid_type": l.bid_type or '', "winner": l.winner or '', "related_customer_ids": l.related_customer_ids or '', "serial_no": l.serial_no or '', "reason": l.reason or '', "source_platform": l.source_platform, "source_url": l.source_url, "status": l.status, "customer_id": l.customer_id, "customer_name": l.customer.name if l.customer else None})

@api.route('/leads/<int:id>', methods=['PUT'])
def update_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status == 'converted':
        return jsonify({"error": "已转化线索不可修改"}), 400
    d = request.get_json() or {}
    if 'status' in d and d['status'] not in ('active', 'abandoned'):
        return jsonify({"error": "状态无效"}), 400
    for key in ['title','bid_number','budget','region','purchaser','contact_name','contact_phone','address','service_content','match_keywords','match_level','match_score','match_reason','assignee','bid_type','winner','related_customer_ids','source_platform','source_url','status','customer_id']:
        if key in d: setattr(l, key, d[key])
    if 'deadline' in d: l.deadline = _parse_date(d.get('deadline'))
    db.session.commit()
    return jsonify({"id": l.id, "message": "更新成功"})

def _find_or_create_customer(name, source, remark):
    """按名称匹配或创建客户，返回客户实例；名称为空返回 None。"""
    name = (name or '').strip()
    if not name:
        return None
    customer = Customer.query.filter_by(name=name[:200], is_archived=False).first()
    if not customer:
        customer = Customer(name=name[:200], source=source, remark=remark)
        db.session.add(customer)
        db.session.flush()
    return customer

@api.route('/leads/<int:id>/convert', methods=['POST'])
def convert_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status != 'active': return jsonify({"error": "仅待转化线索可转化"}), 400
    d = request.get_json() or {}
    related_ids = []
    # 中标/成交公告：支持多家中标单位 + 采购单位，全部建/匹配客户并记录关联
    winner_names = [n for n in (d.get('winner_customer_names') or []) if str(n).strip()]
    purchaser_names = [n for n in (d.get('purchaser_customer_names') or []) if str(n).strip()]
    if winner_names or purchaser_names:
        for n in winner_names:
            c = _find_or_create_customer(n, '线索转化-中标单位', f"由中标公告[{l.title[:60]}]转化时创建")
            if c:
                related_ids.append(c.id)
        for n in purchaser_names:
            c = _find_or_create_customer(n, '线索转化-采购单位', f"由中标公告[{l.title[:60]}]转化时创建")
            if c and c.id not in related_ids:
                related_ids.append(c.id)
        # 商机主客户：优先第一家中标单位（合作目标），否则采购单位
        customer_id = related_ids[0] if related_ids else d.get('customer_id', l.customer_id)
        # 主客户之外的其他关联方写入 related_customer_ids
        l.related_customer_ids = ','.join(str(i) for i in related_ids)
    else:
        customer_id = d.get('customer_id', l.customer_id)
        # 未选择客户时，自动按线索采购方创建客户
        if not customer_id:
            customer = _find_or_create_customer(
                d.get('customer_name') or l.purchaser,
                '线索转化自动创建', f"由线索[{l.title[:60]}]转化时自动创建")
            if customer:
                customer_id = customer.id
    contact_id = d.get('contact_id')
    # 未选择联系人时，按线索抽取的联系人自动创建
    contact_name = (d.get('contact_name') or l.contact_name or '').strip()
    if not contact_id and contact_name and customer_id:
        contact = Contact(
            name=contact_name[:100],
            phone=(d.get('contact_phone') or l.contact_phone or '')[:100],
            customer_id=customer_id,
            notes=f"由线索[{l.title[:60]}]转化自动创建",
        )
        db.session.add(contact)
        db.session.flush()
        contact_id = contact.id
    o = Opportunity(lead_id=l.id, customer_id=customer_id, contact_id=contact_id,
                    title=d.get('title', l.title), amount=d.get('amount', l.budget),
                    current_stage=d.get('stage', '初步接触'),
                    source_url=l.source_url or '')
    db.session.add(o)
    l.status = 'converted'
    # 转化原因写入商机的第一条联络记录
    reason = (d.get('reason') or '').strip()
    if reason:
        db.session.flush()
        db.session.add(Activity(
            customer_id=customer_id, contact_id=contact_id, opportunity_id=o.id, lead_id=l.id,
            method='转化', content=reason, activity_time=datetime.now()))
    # 回写客户关联：已转化线索在列表中能显示客户名，避免关联断链
    if customer_id:
        l.customer_id = customer_id
    db.session.commit()
    return jsonify({"id": o.id, "message": "已转为商机"})

@api.route('/leads/<int:id>/abandon', methods=['POST'])
def abandon_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status == 'converted':
        return jsonify({"error": "已转化线索不可删除"}), 400
    l.status = 'abandoned'
    l.reason = (request.get_json() or {}).get('reason', '')[:300]
    db.session.commit()
    return jsonify({"message": "已删除，可在已删除中恢复"})

@api.route('/opportunities', methods=['GET'])
def list_opportunities():
    ops = Opportunity.query.options(
        joinedload(Opportunity.customer),
        joinedload(Opportunity.contact),
        joinedload(Opportunity.stage_records),
    ).order_by(Opportunity.created_at.desc()).all()
    return jsonify([{"id": o.id, "title": o.title, "amount": o.amount, "source_url": o.source_url or '', "current_stage": o.current_stage, "probability": o.probability or 20, "expected_close": str(o.expected_close.date()) if o.expected_close else None, "customer_id": o.customer_id, "customer_name": o.customer.name if o.customer else None, "contact_id": o.contact_id, "contact_name": o.contact.name if o.contact else None, "lead_id": o.lead_id, "created_at": str(o.created_at.date()) if o.created_at else None, "stages": [{"stage": s.stage_name, "content": s.content, "deadline": str(s.deadline.date()) if s.deadline else None, "status": s.status, "created_at": str(s.created_at.date()) if s.created_at else None} for s in o.stage_records]} for o in ops])

@api.route('/opportunities/<int:id>', methods=['GET'])
def get_opportunity(id):
    o = Opportunity.query.options(
        joinedload(Opportunity.stage_records),
        joinedload(Opportunity.activities).joinedload(Activity.contact),
        joinedload(Opportunity.customer),
        joinedload(Opportunity.contact),
    ).get_or_404(id)
    lead = Lead.query.get(o.lead_id) if o.lead_id else None
    return jsonify({"id": o.id, "title": o.title, "amount": o.amount, "source_url": o.source_url or (lead.source_url if lead else '') or '', "current_stage": o.current_stage, "probability": o.probability or 20, "expected_close": str(o.expected_close.date()) if o.expected_close else None, "customer_id": o.customer_id, "customer_name": o.customer.name if o.customer else None, "contact_id": o.contact_id, "contact_name": o.contact.name if o.contact else None, "lead_id": o.lead_id, "lead_title": lead.title if lead else None, "stages": [{"id": s.id, "stage": s.stage_name, "content": s.content, "deadline": str(s.deadline.date()) if s.deadline else None, "status": s.status, "add_to_kanban": s.add_to_kanban} for s in o.stage_records], "activities": [{"id": a.id, "time": str(a.activity_time.date()) if a.activity_time else None, "method": a.method, "content": a.content, "contact_name": a.contact.name if a.contact else None, "next_followup_time": str(a.next_followup_time.date()) if a.next_followup_time else None, "next_followup_content": a.next_followup_content} for a in sorted(o.activities, key=lambda x: x.activity_time or datetime.min)]})

@api.route('/opportunities/<int:id>/stages', methods=['POST'])
def add_stage_record(id):
    o = Opportunity.query.get_or_404(id)
    d = request.get_json() or {}
    stage_name = (d.get('stage_name') or '').strip()
    if not stage_name:
        abort(400, description="阶段名称不能为空")
    record = StageRecord(opportunity_id=o.id, stage_name=stage_name, content=d.get('content',''), status='pending', add_to_kanban=d.get('add_to_kanban', False))
    record.deadline = _parse_date(d.get('deadline'))
    if d.get('status'): record.status = d['status']
    o.current_stage = stage_name
    db.session.add(record)
    if record.add_to_kanban:
        db.session.flush()
        _add_kanban_card(
            title=record.stage_name and f"[{record.stage_name}] {o.title[:50]}" or o.title,
            description=record.content,
            deadline=record.deadline,
            source_type='stage',
            source_id=record.id,
        )
    db.session.commit()
    return jsonify({"id": record.id, "message": "阶段记录已添加"})

@api.route('/stages', methods=['GET'])
def list_stages():
    stages = OpportunityStage.query.order_by(OpportunityStage.sort_order).all()
    return jsonify([{"id": s.id, "name": s.name, "sort_order": s.sort_order} for s in stages])

@api.route('/stages', methods=['POST'])
def create_stage():
    d = request.get_json()
    s = OpportunityStage(name=d['name'], sort_order=d.get('sort_order', OpportunityStage.query.count()))
    db.session.add(s)
    db.session.commit()
    return jsonify({"id": s.id})

@api.route('/stages/<int:id>', methods=['PUT'])
def update_stage(id):
    s = OpportunityStage.query.get_or_404(id)
    d = request.get_json()
    if 'name' in d: s.name = d['name']
    if 'sort_order' in d: s.sort_order = d['sort_order']
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/stages/<int:id>', methods=['DELETE'])
def delete_stage(id):
    s = OpportunityStage.query.get_or_404(id)
    db.session.delete(s)
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/contacts', methods=['GET'])
def list_contacts():
    q = request.args.get('search', '')
    customer_id = _int_arg('customer_id')
    query = Contact.query.options(joinedload(Contact.customer))
    if q: query = query.filter(Contact.name.contains(q))
    if customer_id: query = query.filter_by(customer_id=customer_id)
    return jsonify([{"id": c.id, "name": c.name, "title": c.title, "phone": c.phone, "email": c.email, "wechat": c.wechat, "role": c.role or '', "tags": c.tags or '', "avatar": c.avatar or c.name[0] if c.name else '', "importance": c.importance, "customer_id": c.customer_id, "customer_name": c.customer.name if c.customer else None, "business_scope": c.business_scope, "notes": c.notes} for c in query.all()])

@api.route('/contacts', methods=['POST'])
def create_contact():
    d = request.get_json() or {}
    _require_fields(d, 'name')
    name = str(d['name']).strip()[:100]
    c = Contact(name=name, title=d.get('title',''), phone=d.get('phone',''), email=d.get('email',''), wechat=d.get('wechat',''), role=d.get('role',''), tags=d.get('tags',''), avatar=d.get('avatar','') or (name[0] if name else ''), importance=d.get('importance',''), customer_id=d.get('customer_id'), business_scope=d.get('business_scope',''), notes=d.get('notes',''))
    db.session.add(c)
    db.session.commit()
    return jsonify({"id": c.id, "message": "创建成功"})

@api.route('/contacts/<int:id>', methods=['GET'])
def get_contact(id):
    c = Contact.query.get_or_404(id)
    customer = c.customer
    news = [{"id": n.id, "title": n.title, "date": str(n.publish_date.date()) if n.publish_date else None, "url": n.url} for n in customer.news_items] if customer else []
    contact_news = [{"id": n.id, "title": n.title, "url": n.url, "source_name": n.source_name or '', "date": str(n.publish_date.date()) if n.publish_date else None, "event_time": str(n.event_time.date()) if n.event_time else None, "summary": n.summary or '', "crawled_at": str(n.crawled_at) if n.crawled_at else None} for n in c.news_items]
    return jsonify({"id": c.id, "name": c.name, "title": c.title, "phone": c.phone, "email": c.email, "wechat": c.wechat, "role": c.role or '', "tags": c.tags or '', "avatar": c.avatar or (c.name[0] if c.name else ''), "importance": c.importance, "customer_id": c.customer_id, "customer_name": customer.name if customer else None, "business_scope": c.business_scope, "notes": c.notes, "news": news, "contact_news": contact_news})

@api.route('/contacts/<int:id>', methods=['PUT'])
def update_contact(id):
    c = Contact.query.get_or_404(id)
    d = request.get_json() or {}
    for key in ['name','title','phone','email','wechat','role','tags','avatar','importance','customer_id','business_scope','notes']:
        if key in d: setattr(c, key, d[key])
    db.session.commit()
    return jsonify({"id": c.id, "message": "更新成功"})

@api.route('/contacts/<int:id>', methods=['DELETE'])
def delete_contact(id):
    c = Contact.query.get_or_404(id)
    # 清理关联引用：动态新闻随联系人删除，活动/联络计划/商机保留但解除关联
    ContactNews.query.filter_by(contact_id=id).delete()
    Activity.query.filter_by(contact_id=id).update({'contact_id': None})
    FollowUp.query.filter_by(contact_id=id).update({'contact_id': None})
    Opportunity.query.filter_by(contact_id=id).update({'contact_id': None})
    db.session.delete(c)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/activities', methods=['GET'])
def list_activities():
    q = request.args.get('search', '')
    method = request.args.get('method', '')
    customer_id = _int_arg('customer_id')
    opportunity_id = _int_arg('opportunity_id')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    query = Activity.query.options(
        joinedload(Activity.customer), joinedload(Activity.contact),
        joinedload(Activity.opportunity), joinedload(Activity.lead),
    )
    if q: query = query.filter(Activity.content.contains(q))
    if method: query = query.filter_by(method=method)
    if customer_id: query = query.filter_by(customer_id=customer_id)
    if opportunity_id: query = query.filter_by(opportunity_id=opportunity_id)
    if date_from:
        d = _parse_date(date_from)
        if d: query = query.filter(Activity.activity_time >= d)
    if date_to:
        d = _parse_date(date_to)
        if d: query = query.filter(Activity.activity_time < d + timedelta(days=1))
    acts = query.order_by(Activity.activity_time.desc()).all()
    return jsonify([{"id": a.id, "title": a.title, "method": a.method, "content": a.content, "activity_time": str(a.activity_time) if a.activity_time else None, "next_followup_time": str(a.next_followup_time.date()) if a.next_followup_time else None, "next_followup_content": a.next_followup_content, "customer_id": a.customer_id, "customer_name": a.customer.name if a.customer else None, "contact_id": a.contact_id, "contact_name": a.contact.name if a.contact else None, "opportunity_id": a.opportunity_id, "opportunity_title": a.opportunity.title if a.opportunity else None, "lead_id": a.lead_id} for a in acts])

@api.route('/activities', methods=['POST'])
def create_activity():
    d = request.get_json() or {}
    a = Activity(title=_text(d.get('title')), customer_id=d.get('customer_id'), contact_id=d.get('contact_id'), opportunity_id=d.get('opportunity_id'), lead_id=d.get('lead_id'), method=_text(d.get('method')), content=_text(d.get('content')), activity_time=_parse_datetime(d.get('time')) or datetime.now(), next_followup_time=_parse_date(d.get('next_time')), next_followup_content=_text(d.get('next_content')), add_to_kanban=d.get('add_to_kanban', False))
    db.session.add(a)
    if a.add_to_kanban:
        db.session.flush()
        _add_kanban_card(
            title=_text(d.get('content'))[:60] or _text(d.get('title')) or '活动跟进',
            description=f"活动: {_text(d.get('method'))} | 客户: {a.customer.name if a.customer else '-'}",
            deadline=a.next_followup_time,
            source_type='activity',
            source_id=a.id,
        )
    db.session.commit()
    # Auto-create follow-up with source activity info
    if d.get('next_time'):
        act_content = _text(d.get('content'))
        fu_content = _text(d.get('next_content')) or f"跟进: {act_content[:80]}"
        ai_suggested = f"来源于活动记录 [{(_text(d.get('method')) or '活动')}] 客户: {a.customer.name if a.customer else '-'} | 内容: {act_content[:100]}"
        fu = FollowUp(
            contact_id=d.get('contact_id'),
            customer_id=d.get('customer_id'),
            opportunity_id=d.get('opportunity_id'),
            plan_date=_parse_date(d.get('next_time')),
            content=fu_content,
            ai_suggested_content=ai_suggested,
            source_activity_id=a.id,
            add_to_kanban=d.get('add_to_kanban', False)
        )
        db.session.add(fu)
        if fu.add_to_kanban:
            db.session.flush()
            _add_kanban_card(
                title=fu_content[:60],
                description=ai_suggested[:100],
                deadline=fu.plan_date,
                source_type='followup',
                source_id=fu.id,
            )
        db.session.commit()
    return jsonify({"id": a.id, "message": "创建成功"})

@api.route('/activities/<int:id>', methods=['GET'])
def get_activity(id):
    a = Activity.query.get_or_404(id)
    return jsonify({"id": a.id, "title": a.title, "method": a.method, "content": a.content, "activity_time": str(a.activity_time) if a.activity_time else None, "next_followup_time": str(a.next_followup_time.date()) if a.next_followup_time else None, "next_followup_content": a.next_followup_content, "customer_id": a.customer_id, "customer_name": a.customer.name if a.customer else None, "contact_id": a.contact_id, "contact_name": a.contact.name if a.contact else None, "opportunity_id": a.opportunity_id, "opportunity_title": a.opportunity.title if a.opportunity else None, "lead_id": a.lead_id})

@api.route('/activities/<int:id>', methods=['PUT'])
def update_activity(id):
    a = Activity.query.get_or_404(id)
    d = request.get_json() or {}
    for key in ['title', 'method', 'content', 'next_followup_content']:
        if key in d: setattr(a, key, _text(d[key]))
    for key in ['customer_id', 'contact_id', 'opportunity_id', 'lead_id']:
        if key in d: setattr(a, key, d[key])
    if 'time' in d: a.activity_time = _parse_datetime(d.get('time')) or a.activity_time
    if 'next_time' in d:
        a.next_followup_time = _parse_date(d.get('next_time'))
        fu = FollowUp.query.filter_by(source_activity_id=a.id).first()
        if fu and not fu.actual_date:
            if a.next_followup_time:
                # 已有联动计划：同步计划日期与内容
                fu.plan_date = a.next_followup_time
                if a.next_followup_content:
                    fu.content = a.next_followup_content
            else:
                # 清空了下次跟进时间：删除未执行的联动计划，避免产生无来源的孤立计划
                db.session.delete(fu)
        elif not fu and a.next_followup_time:
            # 原活动没有跟进时间、编辑时新增：补建联络计划，保持与新建活动一致
            db.session.add(FollowUp(
                contact_id=a.contact_id, customer_id=a.customer_id,
                opportunity_id=a.opportunity_id, lead_id=a.lead_id,
                plan_date=a.next_followup_time,
                content=a.next_followup_content or f"跟进: {(a.content or '')[:80]}",
                ai_suggested_content=f"来源于活动记录 [{(a.method or '活动')}] 客户: {a.customer.name if a.customer else '-'} | 内容: {(a.content or '')[:100]}",
                source_activity_id=a.id,
            ))
    db.session.commit()
    return jsonify({"id": a.id, "message": "更新成功"})

@api.route('/activities/<int:id>', methods=['DELETE'])
def delete_activity(id):
    a = Activity.query.get_or_404(id)
    db.session.delete(a)
    db.session.commit()
    return jsonify({"message": "已删除"})


@api.route('/followups', methods=['GET'])
def list_followups():
    q = request.args.get('search', '')
    customer_id = _int_arg('customer_id')
    contact_id = _int_arg('contact_id')
    status = request.args.get('status', '')
    date_from = request.args.get('date_from', '')
    date_to = request.args.get('date_to', '')
    query = FollowUp.query.options(
        joinedload(FollowUp.customer), joinedload(FollowUp.contact),
        joinedload(FollowUp.opportunity), joinedload(FollowUp.lead),
        joinedload(FollowUp.source_activity),
    )
    if q: query = query.filter(FollowUp.content.contains(q))
    if customer_id: query = query.filter_by(customer_id=customer_id)
    if contact_id: query = query.filter_by(contact_id=contact_id)
    if status == 'pending': query = query.filter(FollowUp.actual_date.is_(None))
    elif status == 'done': query = query.filter(FollowUp.actual_date.isnot(None))
    if date_from:
        d = _parse_date(date_from)
        if d: query = query.filter(FollowUp.plan_date >= d)
    if date_to:
        d = _parse_date(date_to)
        if d: query = query.filter(FollowUp.plan_date < d + timedelta(days=1))
    items = query.order_by(FollowUp.plan_date).all()
    return jsonify([{
        "id": f.id, "contact_id": f.contact_id, "opportunity_id": f.opportunity_id, "lead_id": f.lead_id,
        "contact_name": f.contact.name if f.contact else None,
        "customer_id": f.customer_id,
        "customer_name": f.customer.name if f.customer else None,
        "opportunity_title": f.opportunity.title if f.opportunity else None,
        "plan_date": str(f.plan_date) if f.plan_date else None,
        "content": f.content, "ai_suggested_content": f.ai_suggested_content,
        "actual_date": str(f.actual_date) if f.actual_date else None,
        "actual_content": f.actual_content, "source_activity_id": f.source_activity_id,
        "add_to_kanban": f.add_to_kanban,
        "source_activity_content": _text(f.source_activity.content)[:100] if f.source_activity else None,
        "source_activity_method": f.source_activity.method if f.source_activity else None,
        "source_activity_time": str(f.source_activity.activity_time) if f.source_activity else None
    } for f in items])

@api.route('/followups', methods=['POST'])
def create_followup():
    d = request.get_json() or {}
    f = FollowUp(
        contact_id=d.get('contact_id'), customer_id=d.get('customer_id'),
        opportunity_id=d.get('opportunity_id'),
        plan_date=_parse_date(d.get('plan_date')),
        content=_text(d.get('content')), ai_suggested_content=_text(d.get('ai_content')),
        add_to_kanban=d.get('add_to_kanban', False)
    )
    db.session.add(f)
    if f.add_to_kanban:
        db.session.flush()
        _add_kanban_card(
            title=f.content[:60] or '跟进计划',
            description=f.ai_suggested_content[:100] if f.ai_suggested_content else '',
            deadline=f.plan_date,
            source_type='followup',
            source_id=f.id,
        )
    db.session.commit()
    return jsonify({"id": f.id, "message": "创建成功"})

@api.route('/followups/<int:id>', methods=['GET'])
def get_followup(id):
    f = FollowUp.query.options(
        joinedload(FollowUp.customer), joinedload(FollowUp.contact),
        joinedload(FollowUp.opportunity), joinedload(FollowUp.lead),
    ).get_or_404(id)
    # 该客户/联系人此前的联系记录（供"详情"展示历史）
    history = Activity.query.options(
        joinedload(Activity.contact)
    ).filter(Activity.customer_id == f.customer_id)
    if f.contact_id:
        history = history.filter(Activity.contact_id == f.contact_id)
    history = history.order_by(Activity.activity_time.desc()).limit(20).all()
    return jsonify({
        "id": f.id, "contact_id": f.contact_id, "opportunity_id": f.opportunity_id, "lead_id": f.lead_id,
        "contact_name": f.contact.name if f.contact else None,
        "customer_id": f.customer_id,
        "customer_name": f.customer.name if f.customer else None,
        "opportunity_title": f.opportunity.title if f.opportunity else None,
        "plan_date": str(f.plan_date.date()) if f.plan_date else None,
        "content": f.content, "ai_suggested_content": f.ai_suggested_content,
        "actual_date": str(f.actual_date.date()) if f.actual_date else None,
        "actual_content": f.actual_content, "source_activity_id": f.source_activity_id,
        "history": [{"id": a.id, "time": str(a.activity_time.date()) if a.activity_time else None,
                     "method": a.method, "content": a.content,
                     "contact_name": a.contact.name if a.contact else None,
                     "next_followup_time": str(a.next_followup_time.date()) if a.next_followup_time else None}
                    for a in history],
    })

@api.route('/followups/<int:id>/execute', methods=['POST'])
def execute_followup(id):
    """执行联络计划：标记完成，并把本次联系内容写入日常联络记录。"""
    f = FollowUp.query.get_or_404(id)
    if f.actual_date:
        return jsonify({"error": "该计划已完成，不能重复执行"}), 400
    d = request.get_json() or {}
    content = (d.get('actual_content') or '').strip()
    if not content:
        return jsonify({"error": "请填写本次联系内容"}), 400
    now = datetime.now()
    f.actual_date = now
    f.actual_content = content
    a = Activity(
        customer_id=f.customer_id, contact_id=f.contact_id, opportunity_id=f.opportunity_id,
        lead_id=f.lead_id, method=d.get('method', '电话') or '电话',
        content=content,
        activity_time=now,
        next_followup_time=_parse_date(d.get('next_time')),
        next_followup_content=d.get('next_content', ''),
    )
    db.session.add(a)
    db.session.flush()
    # 闭环：填写了"下次联系时间"时自动生成下一条联络计划，与手工新增活动的行为保持一致
    if a.next_followup_time:
        next_content = (d.get('next_content') or '').strip() or f"跟进: {content[:80]}"
        db.session.add(FollowUp(
            customer_id=f.customer_id, contact_id=f.contact_id,
            opportunity_id=f.opportunity_id, lead_id=f.lead_id,
            plan_date=a.next_followup_time, content=next_content,
            ai_suggested_content=f"来源于联络计划执行 [{a.method}] 客户: {f.customer.name if f.customer else '-'} | 内容: {content[:100]}",
            source_activity_id=a.id,
        ))
    db.session.commit()
    return jsonify({"id": f.id, "activity_id": a.id, "message": "已记录本次联络，并在日常联络中可见"})

@api.route('/followups/<int:id>', methods=['PUT'])
def update_followup(id):
    f = FollowUp.query.get_or_404(id)
    d = request.get_json() or {}
    for key in ['content', 'ai_suggested_content', 'actual_content']:
        if key in d: setattr(f, key, _text(d[key]))
    for key in ['add_to_kanban', 'contact_id', 'customer_id', 'opportunity_id']:
        if key in d: setattr(f, key, d[key])
    if 'plan_date' in d: f.plan_date = _parse_date(d.get('plan_date'))
    if 'actual_date' in d: f.actual_date = _parse_date(d.get('actual_date'))
    db.session.commit()
    return jsonify({"id": f.id, "message": "更新成功"})

@api.route('/followups/<int:id>', methods=['DELETE'])
def delete_followup(id):
    f = FollowUp.query.get_or_404(id)
    db.session.delete(f)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/suggestions', methods=['GET'])
def get_suggestions():
    from app.services.suggestion_engine import generate_suggestions
    suggestions = generate_suggestions()
    return jsonify(suggestions)

@api.route('/customers/<int:id>/news', methods=['GET'])
def customer_news(id):
    news = CustomerNews.query.filter_by(customer_id=id).order_by(CustomerNews.crawled_at.desc()).all()
    return jsonify([{
        "id": n.id, "title": n.title, "content": n.content,
        "url": n.url, "change_type": n.change_type,
        "source_name": n.source_name or '',
        "publish_date": str(n.publish_date) if n.publish_date else None,
        "event_time": str(n.event_time.date()) if n.event_time else None,
        "crawled_at": str(n.crawled_at) if n.crawled_at else None
    } for n in news])

@api.route('/customers/<int:id>/collect-news', methods=['POST'])
def collect_customer_news_api(id):
    from app.services.news_collector import collect_customer_news
    try:
        r = collect_customer_news(id)
        return jsonify({"ok": True, **r})
    except Exception as e:
        return jsonify({"ok": False, "error": f"采集失败: {str(e)[:200]}"}), 200

@api.route('/contacts/<int:id>/collect-news', methods=['POST'])
def collect_contact_news_api(id):
    from app.services.news_collector import collect_contact_news
    try:
        r = collect_contact_news(id)
        return jsonify({"ok": True, **r})
    except Exception as e:
        return jsonify({"ok": False, "error": f"采集失败: {str(e)[:200]}"}), 200

@api.route('/news/collect-all', methods=['POST'])
def collect_all_news_api():
    from app.services.news_collector import collect_all
    d = request.get_json() or {}
    kind = d.get('type', 'all')
    try:
        r = collect_all(kind)
        return jsonify({"ok": True, "message": f"批量采集完成，新增 {r['count']} 条", **r})
    except Exception as e:
        return jsonify({"ok": False, "error": f"批量采集失败: {str(e)[:200]}"}), 200

@api.route('/news/logs', methods=['GET'])
def news_logs():
    logs = CrawlLog.query.order_by(CrawlLog.started_at.desc()).limit(50).all()
    return jsonify([{
        "id": l.id, "task_type": l.task_type, "sources": l.sources,
        "status": l.status, "items_count": l.items_count, "error_count": l.error_count,
        "message": l.message,
        "started_at": str(l.started_at) if l.started_at else None,
        "finished_at": str(l.finished_at) if l.finished_at else None,
    } for l in logs])

@api.route('/news/customer/<int:id>', methods=['DELETE'])
def delete_customer_news(id):
    n = CustomerNews.query.get_or_404(id)
    db.session.delete(n)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/news/contact/<int:id>', methods=['DELETE'])
def delete_contact_news(id):
    n = ContactNews.query.get_or_404(id)
    db.session.delete(n)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/daily-brief', methods=['GET'])
def daily_brief():
    today = datetime.now().strftime('%Y-%m-%d')
    today_acts = Activity.query.filter(db.func.date(Activity.activity_time) == today).all()
    today_followups = FollowUp.query.filter(db.func.date(FollowUp.plan_date) == today).all()
    pending_followups = FollowUp.query.filter(FollowUp.actual_date.is_(None), FollowUp.plan_date <= datetime.now()).all()
    week_from_now = datetime.now() + timedelta(days=7)
    # 截止时间为当天 00:00，需从今天 0 点起算，避免漏掉"今天截止"的线索
    today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    upcoming_deadlines = Lead.query.filter(Lead.deadline.between(today_start, week_from_now), Lead.status == 'active').all()
    return jsonify({
        "today_activities": [{"title": a.title or a.method or _text(a.content)[:60], "method": a.method, "content": _text(a.content)[:80], "contact_name": a.contact.name if a.contact else None, "customer_name": a.customer.name if a.customer else None} for a in today_acts],
        "today_followups": [{"content": f.content, "contact_name": f.contact.name if f.contact else None, "plan_date": str(f.plan_date)} for f in today_followups],
        "overdue_followups": [{"content": f.content, "contact_name": f.contact.name if f.contact else None, "plan_date": str(f.plan_date)} for f in pending_followups],
        "upcoming_deadlines": [{"title": l.title, "level": l.match_level, "deadline": str(l.deadline.date())} for l in upcoming_deadlines]
    })

@api.route('/kanban/boards', methods=['GET'])
def list_boards():
    q = request.args.get('search', '')
    query = KanbanBoard.query
    if q:
        query = query.filter(KanbanBoard.name.contains(q))
    boards = query.all()
    result = []
    for b in boards:
        cols = []
        for col in b.columns:
            cards = [{"id": c.id, "title": c.title, "description": c.description, "color": c.label_color, "deadline": str(c.deadline.date()) if c.deadline else None, "source_type": c.source_type, "source_id": c.source_id} for c in col.cards]
            cols.append({"id": col.id, "name": col.name, "sort_order": col.sort_order, "cards": cards})
        result.append({"id": b.id, "name": b.name, "columns": cols})
    return jsonify(result)

@api.route('/kanban/boards', methods=['POST'])
def create_board():
    d = request.get_json()
    b = KanbanBoard(name=d.get('name','新看板'))
    db.session.add(b)
    db.session.flush()
    for i, name in enumerate(['待处理','进行中','已完成']):
        db.session.add(KanbanColumn(board_id=b.id, name=name, sort_order=i))
    db.session.commit()
    return jsonify({"id": b.id})

@api.route('/kanban/boards/<int:id>', methods=['DELETE'])
def delete_board(id):
    b = KanbanBoard.query.get_or_404(id)
    db.session.delete(b)
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/boards/<int:board_id>/columns', methods=['POST'])
def add_column(board_id):
    board = KanbanBoard.query.get_or_404(board_id)
    d = request.get_json() or {}
    col = KanbanColumn(board_id=board_id, name=_text(d.get('name'), '新列表').strip() or '新列表', sort_order=len(board.columns))
    db.session.add(col)
    db.session.commit()
    return jsonify({"id": col.id})

@api.route('/kanban/cards/<int:card_id>/move', methods=['POST'])
def move_card(card_id):
    card = KanbanCard.query.get_or_404(card_id)
    d = request.get_json() or {}
    col = KanbanColumn.query.get_or_404(d.get('column_id'))
    position = d.get('position')
    if position is not None:
        try:
            position = int(position)
        except (TypeError, ValueError):
            abort(400, description="position 必须为整数")
    card.column_id = col.id
    if position is None:
        # 移动到目标列末尾
        card.sort_order = (db.session.query(db.func.max(KanbanCard.sort_order))
                           .filter_by(column_id=col.id).scalar() or 0) + 1
    else:
        # 插入到目标列指定位置（0-based），列内其余卡片重新编号
        siblings = [c for c in KanbanCard.query.filter_by(column_id=col.id)
                    .order_by(KanbanCard.sort_order).all() if c.id != card_id]
        position = max(0, min(position, len(siblings)))
        siblings.insert(position, card)
        for i, c in enumerate(siblings):
            c.sort_order = i
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/cards', methods=['POST'])
def create_card():
    d = request.get_json() or {}
    if not (d.get('title') or '').strip():
        return jsonify({"error": "标题不能为空"}), 400
    col = KanbanColumn.query.get_or_404(d.get('column_id'))
    next_order = (db.session.query(db.func.max(KanbanCard.sort_order))
                  .filter_by(column_id=col.id).scalar() or 0) + 1
    card = KanbanCard(column_id=col.id, title=d['title'].strip(),
                      description=d.get('description', ''),
                      label_color=d.get('color', 'blue'),
                      deadline=_parse_date(d.get('deadline')),
                      sort_order=next_order)
    db.session.add(card)
    db.session.commit()
    return jsonify({"id": card.id})

@api.route('/kanban/cards/<int:card_id>', methods=['PUT'])
def update_card(card_id):
    card = KanbanCard.query.get_or_404(card_id)
    d = request.get_json() or {}
    if 'title' in d:
        card.title = (d.get('title') or '').strip() or card.title
    if 'description' in d:
        card.description = d.get('description', '')
    if 'color' in d:
        card.label_color = d.get('color', 'blue')
    if 'deadline' in d:
        card.deadline = _parse_date(d.get('deadline'))
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/columns/<int:col_id>', methods=['PUT'])
def update_column(col_id):
    col = KanbanColumn.query.get_or_404(col_id)
    d = request.get_json() or {}
    if (d.get('name') or '').strip():
        col.name = d['name'].strip()
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/columns/<int:col_id>', methods=['DELETE'])
def delete_column(col_id):
    col = KanbanColumn.query.get_or_404(col_id)
    db.session.delete(col)
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/boards/<int:board_id>/columns/reorder', methods=['POST'])
def reorder_columns(board_id):
    d = request.get_json() or {}
    ids = d.get('ids') or []
    if not isinstance(ids, list):
        abort(400, description="ids 必须为数组")
    for i, cid in enumerate(ids):
        if cid is None:
            continue
        try:
            cid = int(cid)
        except (TypeError, ValueError):
            abort(400, description="ids 元素必须为整数")
        col = KanbanColumn.query.get(cid)
        if col and col.board_id == board_id:
            col.sort_order = i
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/cards/<int:card_id>', methods=['DELETE'])
def delete_card(card_id):
    card = KanbanCard.query.get_or_404(card_id)
    db.session.delete(card)
    db.session.commit()
    return jsonify({"ok": True})

@api.route('/kanban/import', methods=['POST'])
def import_to_kanban():
    d = request.get_json() or {}
    board_id = d.get('board_id')
    items = d.get('items', [])
    if not items:
        abort(400, description="items 不能为空")
    board = KanbanBoard.query.get_or_404(board_id)
    if not isinstance(items, list) or not all(isinstance(i, dict) for i in items):
        abort(400, description="items 必须为对象数组")
    target_col = board.columns[0] if board.columns else None
    if not target_col:
        target_col = KanbanColumn(board_id=board_id, name='待处理', sort_order=0)
        db.session.add(target_col)
        db.session.flush()
    for item in items:
        next_order = (db.session.query(db.func.max(KanbanCard.sort_order))
                      .filter_by(column_id=target_col.id).scalar() or 0) + 1
        card = KanbanCard(column_id=target_col.id, title=item.get('title',''), description=item.get('description',''), label_color=item.get('color','blue'), deadline=_parse_date(item.get('deadline')), source_type=item.get('source_type',''), source_id=item.get('source_id'), sort_order=next_order)
        db.session.add(card)
    db.session.commit()
    return jsonify({"message": f"已导入 {len(items)} 张卡片"})

@api.route('/config', methods=['GET'])
def get_config():
    configs = SystemConfig.query.all()
    return jsonify({c.key: {"value": c.value, "description": c.description} for c in configs})

@api.route('/config', methods=['PUT'])
def update_config():
    d = request.get_json()
    for key, value in d.items():
        config = SystemConfig.query.filter_by(key=key).first()
        if config: config.value = str(value)
        else:
            config = SystemConfig(key=key, value=str(value))
            db.session.add(config)
    db.session.commit()
    return jsonify({"message": "配置已更新"})

@api.route('/config/test-ai', methods=['POST'])
def test_ai_connection():
    configs = {c.key: c.value for c in SystemConfig.query.all()}
    api_key = configs.get('ai_api_key', '')
    endpoint = configs.get('ai_api_endpoint', 'https://api.openai.com/v1')
    model = configs.get('ai_model', 'gpt-4o')
    if not api_key:
        return jsonify({"ok": False, "error": "请先配置 API Key"}), 400
    try:
        resp = http_requests.post(
            endpoint.rstrip('/') + '/chat/completions',
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": model, "messages": [{"role": "user", "content": "hello"}], "max_tokens": 10},
            timeout=180
        )
        if resp.status_code == 200:
            return jsonify({"ok": True, "message": f"连接成功！模型 {model} 响应正常", "model": model})
        else:
            return jsonify({"ok": False, "error": f"连接失败 (HTTP {resp.status_code}): {resp.text[:200]}"}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": f"连接异常: {str(e)}"}), 200

@api.route('/config/crawl-targets', methods=['GET'])
def get_crawl_targets():
    configs = {c.key: c.value for c in SystemConfig.query.all()}
    targets = configs.get('crawl_targets', '')
    if targets:
        try:
            return jsonify(json.loads(targets))
        except:
            pass
    return jsonify([
        {"name": "中国政府采购网", "url": "http://search.ccgp.gov.cn/bxsearch", "enabled": True, "keywords": "无人机,林业,病虫害,巡检"},
        {"name": "中国采购与招标网", "url": "https://www.chinabidding.com", "enabled": False, "keywords": "无人机,林业"},
    ])

@api.route('/config/crawl-targets', methods=['PUT'])
def save_crawl_targets():
    d = request.get_json()
    config = SystemConfig.query.filter_by(key='crawl_targets').first()
    val = json.dumps(d, ensure_ascii=False)
    if config: config.value = val
    else:
        config = SystemConfig(key='crawl_targets', value=val, description='爬取目标站点配置')
        db.session.add(config)
    db.session.commit()
    return jsonify({"message": "爬取站点已保存"})

@api.route('/crawl', methods=['POST'])
def trigger_crawl():
    from app.services.crawler import start_crawl_background
    started = start_crawl_background(current_app._get_current_object())
    if started:
        return jsonify({"ok": True, "running": True, "message": "采集已启动，正在抓取并 AI 分析..."})
    return jsonify({"ok": False, "running": True, "error": "采集已在运行中，请稍候"}), 200

@api.route('/crawl/status', methods=['GET'])
def crawl_status():
    from app.services.crawler import get_crawl_status
    return jsonify(get_crawl_status())

@api.route('/ai/urgent-tasks', methods=['GET'])
def get_urgent_tasks():
    """AI 分析联系记录与项目数据，生成当日跟进方案（带 30 分钟缓存）。"""
    from app.services.ai_client import generate_daily_plan
    now = datetime.now()
    cached = SystemConfig.query.filter_by(key='ai_urgent_tasks').first()
    cached_at = SystemConfig.query.filter_by(key='ai_urgent_tasks_at').first()
    ts = None
    if cached_at and cached_at.value:
        try:
            ts = datetime.strptime(cached_at.value, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            ts = None
    if cached and cached.value and ts and (now - ts).total_seconds() < 1800:
        try:
            return jsonify({"ok": True, "source": "cache", "generated_at": cached_at.value,
                            **json.loads(cached.value)})
        except (json.JSONDecodeError, TypeError):
            pass
    try:
        plan = generate_daily_plan()
        store = SystemConfig.query.filter_by(key='ai_urgent_tasks').first()
        if store:
            store.value = json.dumps(plan, ensure_ascii=False)
        else:
            store = SystemConfig(key='ai_urgent_tasks', value=json.dumps(plan, ensure_ascii=False),
                                 description='AI 每日跟进方案')
            db.session.add(store)
        at = SystemConfig.query.filter_by(key='ai_urgent_tasks_at').first()
        ts_str = now.strftime('%Y-%m-%d %H:%M:%S')
        if at:
            at.value = ts_str
        else:
            at = SystemConfig(key='ai_urgent_tasks_at', value=ts_str, description='AI 方案生成时间')
            db.session.add(at)
        db.session.commit()
        return jsonify({"ok": True, "source": "ai", "generated_at": ts_str, **plan})
    except Exception as e:
        return jsonify({"ok": False, "error": f"AI 分析失败: {str(e)[:200]}"}), 200

@api.route('/ai/urgent-tasks/refresh', methods=['POST'])
def refresh_urgent_tasks():
    SystemConfig.query.filter_by(key='ai_urgent_tasks_at').delete()
    db.session.commit()
    return get_urgent_tasks()

@api.route('/leads/<int:id>', methods=['DELETE'])
def delete_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status == 'converted':
        return jsonify({"error": "已转化线索不可删除"}), 400
    # 清理关联引用，避免孤儿数据（商机/活动/联络计划的 lead_id 悬空）
    Opportunity.query.filter_by(lead_id=id).update({'lead_id': None})
    Activity.query.filter_by(lead_id=id).update({'lead_id': None})
    FollowUp.query.filter_by(lead_id=id).update({'lead_id': None})
    db.session.delete(l)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/opportunities', methods=['POST'])
def create_opportunity():
    d = request.get_json() or {}
    _require_fields(d, 'title')
    o = Opportunity(title=str(d['title']).strip()[:500], customer_id=d.get('customer_id'), contact_id=d.get('contact_id'), amount=d.get('amount',''), source_url=d.get('source_url','') or '', current_stage=d.get('current_stage','初步接触'), probability=d.get('probability', 20), expected_close=_parse_date(d.get('expected_close')))
    db.session.add(o)
    db.session.commit()
    return jsonify({"id": o.id, "message": "创建成功"})

@api.route('/opportunities/<int:id>', methods=['PUT'])
def update_opportunity(id):
    o = Opportunity.query.get_or_404(id)
    d = request.get_json() or {}
    old_stage = o.current_stage
    for key in ['title','amount','current_stage','customer_id','contact_id','probability','source_url']:
        if key in d: setattr(o, key, d[key])
    if 'expected_close' in d:
        o.expected_close = _parse_date(d.get('expected_close'))
    # 阶段变更自动写入阶段记录，保证商机流转时间轴完整可追溯
    if o.current_stage and o.current_stage != old_stage:
        db.session.add(StageRecord(
            opportunity_id=o.id, stage_name=o.current_stage,
            content=f"阶段由 [{old_stage or '未设置'}] 调整为 [{o.current_stage}]",
            status='completed',
        ))
    db.session.commit()
    return jsonify({"id": o.id, "message": "更新成功"})

@api.route('/opportunities/<int:id>', methods=['DELETE'])
def delete_opportunity(id):
    o = Opportunity.query.get_or_404(id)
    # 清理关联引用：阶段记录随商机删除，活动/联络计划保留但解除关联
    StageRecord.query.filter_by(opportunity_id=id).delete()
    Activity.query.filter_by(opportunity_id=id).update({'opportunity_id': None})
    FollowUp.query.filter_by(opportunity_id=id).update({'opportunity_id': None})
    db.session.delete(o)
    db.session.commit()
    return jsonify({"message": "已删除"})

@api.route('/options', methods=['GET'])
def get_options():
    configs = {c.key: c.value for c in SystemConfig.query.all()}
    def parse_list(key, default):
        val = configs.get(key, '')
        if val:
            try:
                return json.loads(val)
            except:
                return [v.strip() for v in val.split(',') if v.strip()]
        return default
    return jsonify({
        "customer_types": parse_list('opt_customer_types', ['政府部门', '事业单位', '国有企业', '民营企业', '科研院所', '其他']),
        "customer_levels": parse_list('opt_customer_levels', ['A-重点客户', 'B-重要客户', 'C-一般客户', 'D-潜在客户']),
        "regions": parse_list('opt_regions', ['北京','上海','重庆','天津','河北','山西','辽宁','吉林','黑龙江','江苏','浙江','安徽','福建','江西','山东','河南','湖北','湖南','广东','海南','四川','贵州','云南','陕西','甘肃','青海','内蒙古','广西','西藏','宁夏','新疆']),
    })

@api.route('/leads/<int:id>/claim', methods=['POST'])
def claim_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status != 'pool':
        return jsonify({"error": "仅公海池线索可领取"}), 400
    d = request.get_json() or {}
    l.status = 'active'
    l.assignee = d.get('assignee', '李明')
    db.session.commit()
    return jsonify({"id": l.id, "message": f"已领取线索: {l.title[:30]}"})

@api.route('/leads/<int:id>/release', methods=['POST'])
def release_lead(id):
    l = Lead.query.get_or_404(id)
    if l.status != 'active':
        return jsonify({"error": "仅待转化线索可释放至公海"}), 400
    l.status = 'pool'
    l.assignee = ''
    l.reason = ((request.get_json() or {}).get('reason') or '')[:300]
    db.session.commit()
    return jsonify({"message": "已释放至公海池"})

def _esc_md(s):
    """转义文本中的 HTML 字符，防止原文内容被当作标签渲染。"""
    return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def _backfill_summary(lead, raw_text):
    """线索的 service_content 缺少公告概要时，从全文提取并回填（惰性补齐存量数据）。"""
    if not raw_text or '公告概要' in (lead.service_content or ''):
        return
    from app.services.crawler import extract_notice_summary, build_service_content
    summary = extract_notice_summary(raw_text)
    if summary:
        lead.service_content = build_service_content(lead, summary)


def _html_to_md(soup):
    """按 DOM 顺序把正文转为近似 Markdown：标题层级/段落/列表/表格。"""
    out, seen = [], set()
    if not soup.body:
        return ''
    tags = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'li', 'tr']
    for el in soup.body.find_all(tags):
        if el in seen:
            continue
        for d in el.find_all(True):
            seen.add(d)
        if el.name == 'tr':
            tbl = el.find_parent('table')
            if tbl and tbl in seen:
                continue
            cells = [c.get_text(' ', strip=True) for c in el.find_all(['td', 'th'])]
            cells = [c.replace('|', '/') for c in cells if c != '' or True]
            if not any(cells):
                continue
            out.append('| ' + ' | '.join(cells) + ' |')
            first_row = tbl.find('tr') if tbl else None
            if el.find('th') or (first_row is not None and el is first_row):
                cols = len(cells)
                out.append('|' + '---|' * cols)
            continue
        text = el.get_text(' ', strip=True)
        if not text:
            continue
        if el.name.startswith('h'):
            level = int(el.name[1])
            out.append('#' * min(level + 1, 5) + ' ' + text)
        elif el.name == 'li':
            out.append('- ' + text)
        else:
            out.append(text)
        out.append('')
    md = '\n'.join(out)
    # 修补表格分隔行：若 | 行后紧跟另一个 | 行且无分隔行，插入之
    fixed = []
    for i, line in enumerate(md.split('\n')):
        fixed.append(line)
        if (line.startswith('|') and not line.startswith('|---')
                and i + 1 < len(md.split('\n')) and md.split('\n')[i + 1].startswith('|')
                and not md.split('\n')[i + 1].startswith('|---')):
            cols = line.count('|') - 1
            fixed.append('|' + '---|' * cols)
    return '\n'.join(fixed)[:60000]


def _text_to_md(text):
    """采集存储的纯文本 → 启发式 Markdown：章节号/短行作小标题，其余作段落。"""
    import re as _re
    heading_pat = _re.compile(r'^([一二三四五六七八九十]{1,3}、|（[一二三四五六七八九十]{1,3}）|\d{1,2}[、.．]\s*\S|第[一二三四五六七八九十\d]+[条章节部分])')
    # 页面导航/样板行过滤
    boiler_pat = _re.compile(
        r'^(首页|关闭|打印|分享|上一篇|下一篇|当前位置|»|【|】|服务热线|服务投诉|财政部唯一指定|'
        r'E-?mail|邮件订阅|【打印】|【关闭】|中\s*小|大\s*中\s*小|扫一扫|微信|微博|二维码|'
        r'版权所有|网站地图|主办单位|承办单位|技术支持|浏览次数|附件下载|相关附件|打印本页|关闭窗口|'
        r'政采法规|购买服务|监督检查|信息公告|国际专栏|政采公告|地方公告|中央公告|地方动态|采购需求|'
        r'政采知识|政策法规|互动交流|专题专栏|站内检索|无障碍|长者模式).*'
    )
    lines = [l.strip() for l in (text or '').split('\n') if l.strip()]
    out = []
    for i, line in enumerate(lines):
        esc = _esc_md(line)
        if i == 0 and len(line) > 8:
            out.append('# ' + esc)  # 首行为公告标题
            continue
        if boiler_pat.match(line) or len(line) <= 3:
            continue
        if heading_pat.match(line) and len(line) <= 60:
            out.append('### ' + esc)
        elif (2 <= len(line) <= 6 and not line.endswith(('。', '；', '，', ',', '、'))
              and '：' not in line and ':' not in line and not line.startswith(('http', 'www.'))):
            out.append('**' + esc + '**')  # 字段标签行加粗（采购单位/开标时间等）
        elif (6 < len(line) <= 30 and not line.endswith(('。', '；', '，', ',', '、'))
              and '：' not in line and ':' not in line and not line.startswith(('http', 'www.'))):
            out.append('### ' + esc)
        elif line.endswith(('：', ':')) and len(line) <= 15:
            out.append('**' + esc + '**')  # "公告概要："式标签
        else:
            out.append(esc + '  ')
    return '\n'.join(out)[:60000]


@api.route('/leads/<int:id>/fulltext', methods=['GET'])
def lead_fulltext(id):
    """线索公告全文：返回 Markdown 格式文本，近似还原公告原版式。"""
    l = Lead.query.get_or_404(id)
    if l.full_text:
        _backfill_summary(l, l.full_text)
        db.session.commit()
        return jsonify({"source": "stored", "text": _text_to_md(l.full_text)})
    if not l.source_url:
        return jsonify({"error": "该线索无原文链接，无法获取全文"}), 400
    # SSRF 防护：仅 http/https，且目标主机不得为内网/环回/保留地址
    from urllib.parse import urlparse
    import ipaddress
    import socket
    u = urlparse(l.source_url)
    if u.scheme not in ('http', 'https') or not u.hostname:
        return jsonify({"error": "原文链接不合法"}), 400
    try:
        infos = socket.getaddrinfo(u.hostname, None)
    except OSError:
        return jsonify({"error": "原文链接域名无法解析"}), 400
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if (ip.is_private or ip.is_loopback or ip.is_reserved
                or ip.is_link_local or ip.is_multicast or ip.is_unspecified):
            return jsonify({"error": "原文链接指向受限地址，已拦截"}), 400
    import requests as _requests
    try:
        resp = _requests.get(l.source_url, timeout=15,
                             headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/126.0.0.0 Safari/537.36"},
                             allow_redirects=False)
    except Exception as e:
        return jsonify({"error": f"抓取失败: {e}"}), 502
    if resp.status_code != 200:
        return jsonify({"error": f"原文站点返回 HTTP {resp.status_code}"}), 502
    if not resp.encoding or resp.encoding.lower() == 'iso-8859-1':
        resp.encoding = resp.apparent_encoding or 'utf-8'
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(resp.text, 'html.parser')
    for tag in soup(['script', 'style', 'noscript', 'iframe', 'form', 'button']):
        tag.decompose()
    raw_text = soup.get_text('\n')
    md = _html_to_md(soup)
    if not md.strip():
        md = _text_to_md(raw_text)
    _backfill_summary(l, raw_text)
    db.session.commit()
    return jsonify({"source": "fetched", "text": md})

@api.route('/analytics', methods=['GET'])
def analytics():
    from sqlalchemy import func as sa_func
    import re as _re
    def safe_amount(val):
        if not val: return 0.0
        m = _re.search(r'[\d.]+', str(val))
        return float(m.group()) if m else 0.0
    leads = Lead.query.all()
    opportunities = Opportunity.query.all()
    activities = Activity.query.all()
    # Monthly leads trend (last 6 months)
    monthly = []
    now = datetime.now()
    for i in range(5, -1, -1):
        d = now - timedelta(days=30*i)
        month_str = d.strftime('%Y-%m')
        month_leads = [l for l in leads if l.created_at and l.created_at.strftime('%Y-%m') == month_str]
        converted = [l for l in month_leads if l.status == 'converted']
        monthly.append({"month": d.strftime('%m月'), "leads": len(month_leads), "converted": len(converted)})
    # Funnel by stage: 优先使用配置阶段，并补充数据中出现的其他阶段
    configured = [s.name for s in OpportunityStage.query.order_by(OpportunityStage.sort_order).all()]
    # 配置表可能为空（真实库 opportunity_stages 无数据），此时阶段完全来自商机数据，
    # 必须去重：否则同一阶段会按商机条数重复出现（14 条商机 → 14 个同名"初步接触"）
    seen = list(dict.fromkeys(o.current_stage for o in opportunities if o.current_stage))
    stages_list = list(dict.fromkeys(configured)) + [s for s in seen if s not in configured]
    funnel = []
    for s in stages_list:
        stage_opps = [o for o in opportunities if o.current_stage == s]
        total_amount = sum(safe_amount(o.amount) for o in stage_opps)
        funnel.append({"stage": s, "count": len(stage_opps), "amount": total_amount})
    # Win/loss
    won = len([o for o in opportunities if o.current_stage in ('合同签订', '合同签约')])
    lost = len([o for o in opportunities if o.current_stage == '已丢单'])
    active = len(opportunities) - won - lost
    win_loss = [{"name": "赢单", "value": won}, {"name": "进行中", "value": active}, {"name": "丢单", "value": lost}]
    # Summary stats
    total_amount = sum(safe_amount(o.amount) for o in opportunities)
    won_amount = sum(safe_amount(o.amount) for o in opportunities if o.current_stage == '合同签订')
    conversion_rate = round(len([l for l in leads if l.status == 'converted']) / max(len(leads), 1) * 100, 1)
    return jsonify({
        "summary": {"total_leads": len(leads), "total_opportunities": len(opportunities), "total_amount": total_amount, "won_amount": won_amount, "conversion_rate": conversion_rate, "total_activities": len(activities)},
        "monthly_leads": monthly,
        "funnel": funnel,
        "win_loss": win_loss
    })

# ═══════════════════════════════════════════
# 数据导出（CSV）
# ═══════════════════════════════════════════
EXPORT_TYPES = {
    'leads': {'label': '线索', 'model': Lead},
    'opportunities': {'label': '商机', 'model': Opportunity},
    'contacts': {'label': '联系人', 'model': Contact},
    'customers': {'label': '客户', 'model': Customer},
    'activities': {'label': '日常联络', 'model': Activity},
    'followups': {'label': '联络计划', 'model': FollowUp},
}

def _d(val):
    """日期/时间统一转字符串，None 转 '-'"""
    if val is None:
        return '-'
    if isinstance(val, datetime):
        return val.strftime('%Y-%m-%d %H:%M') if val.hour or val.minute else val.strftime('%Y-%m-%d')
    return str(val) if str(val) else '-'

def _lead_row(l):
    return [l.id, l.title, l.bid_number or '-', l.budget or '-', _d(l.deadline),
            l.region or '-', l.purchaser or '-', l.contact_name or '-', l.contact_phone or '-',
            l.address or '-', l.match_score or 0, l.match_level or '-',
            {'active': '待转化', 'converted': '已转化', 'abandoned': '已删除', 'pool': '公海池'}.get(l.status, l.status),
            l.customer.name if l.customer else '-', l.source_platform or '-', l.source_url or '-', _d(l.created_at)]

def _opp_row(o):
    return [o.id, o.title, o.customer.name if o.customer else '-', o.contact.name if o.contact else '-',
            o.amount or '0', o.current_stage or '-', o.probability or 20, _d(o.expected_close),
            o.source_url or '-', _d(o.created_at)]

def _contact_row(c):
    return [c.id, c.name, c.title or '-', c.customer.name if c.customer else '-', c.phone or '-',
            c.email or '-', c.wechat or '-', c.role or '-', c.tags or '-', c.importance or '-']

def _customer_row(cu):
    return [cu.id, cu.name, cu.short_name or '-', cu.customer_type or '-', cu.level or '-', cu.region or '-',
            cu.website or '-', cu.source or '-', len(cu.contacts), cu.remark or '-']

def _activity_row(a):
    return [a.id, _d(a.activity_time), a.method or '-', a.customer.name if a.customer else '-',
            a.contact.name if a.contact else '-', a.opportunity.title if a.opportunity else '-',
            a.content or '-', _d(a.next_followup_time), a.next_followup_content or '-']

def _followup_row(f):
    return [f.id, _d(f.plan_date), f.customer.name if f.customer else '-', f.contact.name if f.contact else '-',
            f.opportunity.title if f.opportunity else '-', f.content or '-',
            '已完成' if f.actual_date else '待联络', _d(f.actual_date), f.actual_content or '-']

EXPORT_HEADERS = {
    'leads': ['ID', '标题', '招标编号', '预算(万)', '截止日期', '地区', '采购方', '联系人', '联系电话', '地址',
              '匹配度(%)', '匹配等级', '状态', '关联客户', '来源平台', '来源URL', '创建时间'],
    'opportunities': ['ID', '商机名称', '客户', '联系人', '金额(万)', '阶段', '赢率(%)', '预计关闭', '来源URL', '创建时间'],
    'contacts': ['ID', '姓名', '职位', '所属客户', '电话', '邮箱', '微信', '角色', '标签', '重要性'],
    'customers': ['ID', '客户名称', '简称', '类型', '等级', '地区', '官网', '来源', '联系人数', '备注'],
    'activities': ['ID', '时间', '方式', '客户', '联系人', '关联商机', '内容', '预计联系时间', '预计联系内容'],
    'followups': ['ID', '计划日期', '客户', '联系人', '关联商机', '计划内容', '状态', '实际日期', '实际内容'],
}
EXPORT_ROWS = {
    'leads': _lead_row, 'opportunities': _opp_row, 'contacts': _contact_row,
    'customers': _customer_row, 'activities': _activity_row, 'followups': _followup_row,
}

@api.route('/export/<string:etype>', methods=['POST'])
def export_csv(etype):
    """按当前筛选结果导出 CSV。body: {"ids": [1,2,...]}（空/缺省=导出全部）"""
    spec = EXPORT_TYPES.get(etype)
    if not spec:
        return jsonify({"error": f"不支持的导出类型: {etype}"}), 400
    d = request.get_json() or {}
    ids = d.get('ids') or []
    # 预加载导出时用到的人类可读关联，避免逐行触发 N+1 查询
    eager = {
        'leads': [selectinload(Lead.customer)],
        'opportunities': [selectinload(Opportunity.customer), selectinload(Opportunity.contact)],
        'contacts': [selectinload(Contact.customer)],
        'customers': [selectinload(Customer.contacts)],
        'activities': [selectinload(Activity.customer), selectinload(Activity.contact), selectinload(Activity.opportunity)],
        'followups': [selectinload(FollowUp.customer), selectinload(FollowUp.contact), selectinload(FollowUp.opportunity)],
    }
    query = spec['model'].query.options(*eager.get(etype, []))
    if ids:
        query = query.filter(spec['model'].id.in_(ids))
    items = query.all()
    if not items:
        return jsonify({"error": "当前无数据可导出"}), 400

    # UTF-8 BOM 确保 Excel 直接打开不乱码
    buf = io.StringIO()
    buf.write('\ufeff')
    writer = csv.writer(buf)
    writer.writerow(EXPORT_HEADERS[etype])
    for item in items:
        writer.writerow(EXPORT_ROWS[etype](item))
    data = buf.getvalue().encode('utf-8')
    filename = f"{spec['label']}_导出_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    resp = Response(data, mimetype='text/csv; charset=utf-8')
    # HTTP 头仅支持 latin-1：中文文件名按 RFC 5987 做百分号编码
    resp.headers['Content-Disposition'] = f"attachment; filename*=UTF-8''{quote(filename)}"
    return resp
